import React, { createContext, useContext, useState, useEffect } from 'react';
import { INITIAL_EMPLOYEES } from '../data/employees';
import { INITIAL_DEPARTMENTS } from '../data/departments';
import { INITIAL_PROJECTS } from '../data/projects';
import { INITIAL_TASKS } from '../data/tasks';
import { INITIAL_ATTENDANCE } from '../data/attendance';
import { INITIAL_LEAVES, INITIAL_LEAVE_BALANCES } from '../data/leaves';
import { INITIAL_PAYROLL } from '../data/payroll';
import { INITIAL_ANNOUNCEMENTS } from '../data/announcements';
import { INITIAL_NOTIFICATIONS } from '../data/notifications';
import { INITIAL_JOB_OPENINGS, INITIAL_CANDIDATES } from '../data/recruitment';
import { INITIAL_PERFORMANCE } from '../data/performance';
import { INITIAL_AUDIT_LOGS } from '../data/auditLogs';
import { INITIAL_COMPANY_WIFIS, AVAILABLE_SIMULATION_NETWORKS } from '../data/wifiNetworks';
import { INITIAL_ID_CARD_REQUESTS } from '../data/idCards';
import {
  INITIAL_INVENTORY_PRODUCTS,
  INITIAL_INVENTORY_SUPPLIERS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_STOCK_MOVEMENTS
} from '../data/inventory';
import { useAuth } from './AuthContext';
import { useToast } from './ToastContext';
import { api } from '../services/api';

const ERPContext = createContext();

export const CURRENT_DATE_REF = '2026-10-07';

export const INITIAL_WFH_AUTHORIZED = [
  {
    id: 'WFH-AUTH-1001',
    employeeId: 'EMP-1004',
    employeeName: 'Elena Rostova',
    department: 'Engineering',
    designation: 'Senior Frontend Engineer',
    authorizedBy: 'Administrator (Saurabh Kumar)',
    authorizedDate: '2026-09-28',
    validUntil: '2026-10-31',
    status: 'Authorized',
    reason: 'Remote Project Sprint Delivery (Austin/Remote)',
    idCardVerified: true,
    notes: 'Official Admin ID authorization for remote geofence exemption'
  },
  {
    id: 'WFH-AUTH-1002',
    employeeId: 'EMP-1008',
    employeeName: 'Clara Oswald',
    department: 'Engineering',
    designation: 'Staff Backend Architect',
    authorizedBy: 'Administrator (Saurabh Kumar)',
    authorizedDate: '2026-09-25',
    validUntil: '2026-10-31',
    status: 'Authorized',
    reason: 'Cloud Infrastructure Migration & Remote Standup',
    idCardVerified: true,
    notes: 'Admin pre-approved WFH ID access'
  }
];

export const getEffectiveStatus = (task, todayStr = CURRENT_DATE_REF) => {
  if (!task) return 'Pending';
  if (task.status === 'Completed') return 'Completed';
  if (task.dueDate && task.dueDate < todayStr) return 'Overdue';
  return task.status === 'Todo' ? 'Pending' : (task.status || 'Pending');
};

export const calculateCompletionRate = (taskList) => {
  if (!taskList || taskList.length === 0) return 0;
  const completed = taskList.filter(t => getEffectiveStatus(t) === 'Completed').length;
  return Math.round((completed / taskList.length) * 100);
};

export const calculateProductivityScore = (taskList) => {
  if (!taskList || taskList.length === 0) return 0;
  const total = taskList.length;
  const completed = taskList.filter(t => getEffectiveStatus(t) === 'Completed').length;
  const overdue = taskList.filter(t => getEffectiveStatus(t) === 'Overdue').length;
  const inProgress = taskList.filter(t => getEffectiveStatus(t) === 'In Progress').length;
  const onTimeCompleted = taskList.filter(t => t.status === 'Completed' && (!t.dueDate || !t.completionDate || t.completionDate <= t.dueDate)).length;

  const compRate = (completed / total) * 100;
  const onTimeRate = completed > 0 ? (onTimeCompleted / completed) * 100 : 0;
  const overduePenalty = (overdue / total) * 25;
  const progressBonus = (inProgress / total) * 10;

  const rawScore = (compRate * 0.65) + (onTimeRate * 0.25) + progressBonus - overduePenalty;
  return Math.min(100, Math.max(10, Math.round(rawScore)));
};

export const ERPProvider = ({ children }) => {
  const { currentUser } = useAuth();
  const { addToast } = useToast();

  // Helper for localStorage initial state
  const loadState = (key, fallback) => {
    try {
      const saved = localStorage.getItem(`nexora_${key}`);
      if (!saved) return fallback;
      const str = saved.replace(/Alexander Vance/g, 'Saurabh Kumar');
      return JSON.parse(str);
    } catch (e) {
      console.error(`Error loading ${key}`, e);
      return fallback;
    }
  };

  const [employees, setEmployees] = useState(() => {
    const loaded = loadState('employees', INITIAL_EMPLOYEES);
    if (loaded && loaded.some(e => e.id === 'EMP-1001' && e.salary < 1000000)) {
      return INITIAL_EMPLOYEES;
    }
    return loaded;
  });
  const [departments, setDepartments] = useState(() => {
    const loaded = loadState('departments', INITIAL_DEPARTMENTS);
    if (loaded && loaded.some(d => d.budget < 1000000)) {
      return INITIAL_DEPARTMENTS;
    }
    return loaded;
  });
  const [projects, setProjects] = useState(() => {
    const loaded = loadState('projects', INITIAL_PROJECTS);
    if (loaded && loaded.some(p => p.budget < 500000)) {
      return INITIAL_PROJECTS;
    }
    return loaded;
  });
  const [tasks, setTasks] = useState(() => {
    const loaded = loadState('tasks', INITIAL_TASKS);
    if (!loaded || loaded.length < 30 || !loaded[0]?.assignedManagerId || loaded.some(t => t.status === 'Todo')) {
      return INITIAL_TASKS;
    }
    return loaded;
  });
  const [attendance, setAttendance] = useState(() => {
    const loaded = loadState('attendance', INITIAL_ATTENDANCE);
    return loaded.map(a => {
      if (a.id === 'ATT-301' && a.checkIn === '09:05 AM' && !a.checkOut) {
        return { ...a, checkIn: null, checkOut: null, workHours: 0, status: 'Absent' };
      }
      if (a.id === 'ATT-308' && !a.isWFH) {
        return {
          ...a,
          isWFH: true,
          workMode: 'Work From Home',
          networkName: 'Work From Home (HR Authorized)',
          networkVerified: true
        };
      }
      return a;
    });
  });
  const [leaves, setLeaves] = useState(() => loadState('leaves', INITIAL_LEAVES));
  const [leaveBalances, setLeaveBalances] = useState(() => loadState('leaveBalances', INITIAL_LEAVE_BALANCES));
  const [payroll, setPayroll] = useState(() => {
    const loaded = loadState('payroll', INITIAL_PAYROLL);
    if (loaded && loaded.some(p => p.basicSalary < 50000)) {
      return INITIAL_PAYROLL;
    }
    return loaded;
  });
  const [announcements, setAnnouncements] = useState(() => {
    const loaded = loadState('announcements', INITIAL_ANNOUNCEMENTS);
    if (loaded && loaded.some(a => a.description && a.description.includes('$'))) {
      return INITIAL_ANNOUNCEMENTS;
    }
    return loaded;
  });
  const [notifications, setNotifications] = useState(() => loadState('notifications', INITIAL_NOTIFICATIONS));
  const [jobOpenings, setJobOpenings] = useState(() => {
    const loaded = loadState('jobs', INITIAL_JOB_OPENINGS);
    if (loaded && loaded.some(j => j.salaryRange && j.salaryRange.includes('$'))) {
      return INITIAL_JOB_OPENINGS;
    }
    return loaded;
  });
  const [candidates, setCandidates] = useState(() => loadState('candidates', INITIAL_CANDIDATES));
  const [performanceReviews, setPerformanceReviews] = useState(() => loadState('performance', INITIAL_PERFORMANCE));
  const [auditLogs, setAuditLogs] = useState(() => {
    const loaded = loadState('audit_logs', INITIAL_AUDIT_LOGS);
    if (loaded && loaded.some(l => l.details && l.details.includes('$'))) {
      return INITIAL_AUDIT_LOGS;
    }
    return loaded;
  });
  const [companyWifis, setCompanyWifis] = useState(() => loadState('company_wifis', INITIAL_COMPANY_WIFIS));
  const [currentNetwork, setCurrentNetwork] = useState(() => loadState('current_network', AVAILABLE_SIMULATION_NETWORKS[0]));
  const [wifiEnforcementEnabled, setWifiEnforcementEnabled] = useState(() => loadState('wifi_enforcement', true));
  const [wfhAuthorizedEmployees, setWfhAuthorizedEmployees] = useState(() => loadState('wfh_authorized', INITIAL_WFH_AUTHORIZED));
  const [idCardRequests, setIdCardRequests] = useState(() => loadState('id_card_requests', INITIAL_ID_CARD_REQUESTS));

  // Inventory Management State
  const [inventoryProducts, setInventoryProducts] = useState(() => loadState('inventory_products', INITIAL_INVENTORY_PRODUCTS));
  const [inventorySuppliers, setInventorySuppliers] = useState(() => loadState('inventory_suppliers', INITIAL_INVENTORY_SUPPLIERS));
  const [inventoryPurchaseOrders, setInventoryPurchaseOrders] = useState(() => loadState('inventory_pos', INITIAL_PURCHASE_ORDERS));
  const [inventoryStockMovements, setInventoryStockMovements] = useState(() => loadState('inventory_movements', INITIAL_STOCK_MOVEMENTS));

  // Sync to localStorage
  useEffect(() => { localStorage.setItem('nexora_employees', JSON.stringify(employees)); }, [employees]);
  useEffect(() => { localStorage.setItem('nexora_departments', JSON.stringify(departments)); }, [departments]);
  useEffect(() => { localStorage.setItem('nexora_projects', JSON.stringify(projects)); }, [projects]);
  useEffect(() => { localStorage.setItem('nexora_tasks', JSON.stringify(tasks)); }, [tasks]);
  useEffect(() => { localStorage.setItem('nexora_attendance', JSON.stringify(attendance)); }, [attendance]);
  useEffect(() => { localStorage.setItem('nexora_leaves', JSON.stringify(leaves)); }, [leaves]);
  useEffect(() => { localStorage.setItem('nexora_leaveBalances', JSON.stringify(leaveBalances)); }, [leaveBalances]);
  useEffect(() => { localStorage.setItem('nexora_payroll', JSON.stringify(payroll)); }, [payroll]);
  useEffect(() => { localStorage.setItem('nexora_announcements', JSON.stringify(announcements)); }, [announcements]);
  useEffect(() => { localStorage.setItem('nexora_notifications', JSON.stringify(notifications)); }, [notifications]);
  useEffect(() => { localStorage.setItem('nexora_jobs', JSON.stringify(jobOpenings)); }, [jobOpenings]);
  useEffect(() => { localStorage.setItem('nexora_candidates', JSON.stringify(candidates)); }, [candidates]);
  useEffect(() => { localStorage.setItem('nexora_performance', JSON.stringify(performanceReviews)); }, [performanceReviews]);
  useEffect(() => { localStorage.setItem('nexora_audit_logs', JSON.stringify(auditLogs)); }, [auditLogs]);
  useEffect(() => { localStorage.setItem('nexora_company_wifis', JSON.stringify(companyWifis)); }, [companyWifis]);
  useEffect(() => { localStorage.setItem('nexora_current_network', JSON.stringify(currentNetwork)); }, [currentNetwork]);
  useEffect(() => { localStorage.setItem('nexora_wifi_enforcement', JSON.stringify(wifiEnforcementEnabled)); }, [wifiEnforcementEnabled]);
  useEffect(() => { localStorage.setItem('nexora_wfh_authorized', JSON.stringify(wfhAuthorizedEmployees)); }, [wfhAuthorizedEmployees]);
  useEffect(() => { localStorage.setItem('nexora_id_card_requests', JSON.stringify(idCardRequests)); }, [idCardRequests]);
  useEffect(() => { localStorage.setItem('nexora_inventory_products', JSON.stringify(inventoryProducts)); }, [inventoryProducts]);
  useEffect(() => { localStorage.setItem('nexora_inventory_suppliers', JSON.stringify(inventorySuppliers)); }, [inventorySuppliers]);
  useEffect(() => { localStorage.setItem('nexora_inventory_pos', JSON.stringify(inventoryPurchaseOrders)); }, [inventoryPurchaseOrders]);
  useEffect(() => { localStorage.setItem('nexora_inventory_movements', JSON.stringify(inventoryStockMovements)); }, [inventoryStockMovements]);

  // Backend Connectivity & SQLite State Synchronization
  const [isBackendConnected, setIsBackendConnected] = useState(false);

  useEffect(() => {
    let isMounted = true;
    const syncBackendData = async () => {
      try {
        const [
          empRes, deptRes, projRes, taskRes, attRes, wfhRes, idCardRes,
          leavesRes, balancesRes, payRes, prdRes, supRes, poRes, movRes,
          wifiRes, ancRes, notifRes, logRes, jobRes, candRes, perfRes
        ] = await Promise.allSettled([
          api.employees.getAll(),
          api.departments.getAll(),
          api.projects.getAll(),
          api.tasks.getAll(),
          api.attendance.getAll(),
          api.attendance.getWFHAuthorized(),
          api.idCards.getAll(),
          api.leaves.getAll(),
          api.leaves.getBalances(),
          api.payroll.getAll(),
          api.inventory.getProducts(),
          api.inventory.getSuppliers(),
          api.inventory.getPurchaseOrders(),
          api.inventory.getMovements(),
          api.wifis.getAll(),
          api.announcements.getAll(),
          api.notifications.getAll(),
          api.audit.getAll(),
          api.recruitment.getJobs(),
          api.recruitment.getCandidates(),
          api.performance.getAll()
        ]);

        if (!isMounted) return;

        let connected = false;
        if (empRes.status === 'fulfilled' && Array.isArray(empRes.value) && empRes.value.length > 0) {
          setEmployees(empRes.value);
          connected = true;
        }
        if (deptRes.status === 'fulfilled' && Array.isArray(deptRes.value) && deptRes.value.length > 0) setDepartments(deptRes.value);
        if (projRes.status === 'fulfilled' && Array.isArray(projRes.value) && projRes.value.length > 0) setProjects(projRes.value);
        if (taskRes.status === 'fulfilled' && Array.isArray(taskRes.value) && taskRes.value.length > 0) setTasks(taskRes.value);
        if (attRes.status === 'fulfilled' && Array.isArray(attRes.value) && attRes.value.length > 0) setAttendance(attRes.value);
        if (wfhRes.status === 'fulfilled' && Array.isArray(wfhRes.value) && wfhRes.value.length > 0) setWfhAuthorizedEmployees(wfhRes.value);
        if (idCardRes.status === 'fulfilled' && Array.isArray(idCardRes.value) && idCardRes.value.length > 0) setIdCardRequests(idCardRes.value);
        if (leavesRes.status === 'fulfilled' && Array.isArray(leavesRes.value) && leavesRes.value.length > 0) setLeaves(leavesRes.value);
        if (balancesRes.status === 'fulfilled' && Array.isArray(balancesRes.value) && balancesRes.value.length > 0) setLeaveBalances(balancesRes.value);
        if (payRes.status === 'fulfilled' && Array.isArray(payRes.value) && payRes.value.length > 0) setPayroll(payRes.value);
        if (prdRes.status === 'fulfilled' && Array.isArray(prdRes.value) && prdRes.value.length > 0) setInventoryProducts(prdRes.value);
        if (supRes.status === 'fulfilled' && Array.isArray(supRes.value) && supRes.value.length > 0) setInventorySuppliers(supRes.value);
        if (poRes.status === 'fulfilled' && Array.isArray(poRes.value) && poRes.value.length > 0) setInventoryPurchaseOrders(poRes.value);
        if (movRes.status === 'fulfilled' && Array.isArray(movRes.value) && movRes.value.length > 0) setInventoryStockMovements(movRes.value);
        if (wifiRes.status === 'fulfilled' && Array.isArray(wifiRes.value) && wifiRes.value.length > 0) setCompanyWifis(wifiRes.value);
        if (ancRes.status === 'fulfilled' && Array.isArray(ancRes.value) && ancRes.value.length > 0) setAnnouncements(ancRes.value);
        if (notifRes.status === 'fulfilled' && Array.isArray(notifRes.value) && notifRes.value.length > 0) setNotifications(notifRes.value);
        if (logRes.status === 'fulfilled' && Array.isArray(logRes.value) && logRes.value.length > 0) setAuditLogs(logRes.value);
        if (jobRes.status === 'fulfilled' && Array.isArray(jobRes.value) && jobRes.value.length > 0) setJobOpenings(jobRes.value);
        if (candRes.status === 'fulfilled' && Array.isArray(candRes.value) && candRes.value.length > 0) setCandidates(candRes.value);
        if (perfRes.status === 'fulfilled' && Array.isArray(perfRes.value) && perfRes.value.length > 0) setPerformanceReviews(perfRes.value);

        if (connected) {
          setIsBackendConnected(true);
        }
      } catch (err) {
        console.warn('Backend sync error:', err);
      }
    };

    syncBackendData();
    return () => { isMounted = false; };
  }, []);

  // Log Action Helper
  const logAudit = (action, module, details) => {
    const newLog = {
      id: `LOG-${Date.now().toString().slice(-4)}`,
      user: currentUser?.name || 'Saurabh Kumar',
      role: currentUser?.role || 'owner',
      action,
      module,
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'Success',
      details
    };
    setAuditLogs(prev => [newLog, ...prev]);
    api.audit.log(newLog).catch(() => {});
  };

  // Add Notification Helper
  const triggerNotification = (title, message, type, targetRole = ['owner', 'hr', 'manager', 'employee'], link = '/') => {
    const newNotif = {
      id: `NOTIF-${Date.now().toString().slice(-4)}`,
      title,
      message,
      type,
      targetRole,
      read: false,
      timestamp: new Date().toISOString(),
      link
    };
    setNotifications(prev => [newNotif, ...prev]);
    api.notifications.create(newNotif).catch(() => {});
  };

  // =================== EMPLOYEES CRUD ===================
  const addEmployee = (empData) => {
    const newId = `EMP-${1000 + employees.length + 1}`;
    const newEmp = {
      id: newId,
      status: 'Active',
      avatar: empData.avatar || `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`,
      role: 'employee',
      ...empData
    };
    setEmployees(prev => [newEmp, ...prev]);
    api.employees.create(newEmp).catch(() => {});
    logAudit('Employee Added', 'Employees', `Added ${newEmp.fullName} (${newEmp.id}) to ${newEmp.department}`);
    triggerNotification('New Employee Onboarded', `${newEmp.fullName} joined ${newEmp.department}`, 'employee', ['owner', 'hr', 'manager']);
    addToast(`Employee ${newEmp.fullName} added successfully!`, 'success');
    return newEmp;
  };

  const updateEmployee = (id, updatedFields) => {
    setEmployees(prev => prev.map(emp => (emp.id === id ? { ...emp, ...updatedFields } : emp)));
    api.employees.update(id, updatedFields).catch(() => {});
    logAudit('Employee Updated', 'Employees', `Updated details for employee ${id}`);
    addToast('Employee details updated successfully!', 'success');
  };

  const deleteEmployee = (id) => {
    const emp = employees.find(e => e.id === id);
    setEmployees(prev => prev.filter(e => e.id !== id));
    api.employees.delete(id).catch(() => {});
    logAudit('Employee Deleted', 'Employees', `Removed employee ${emp?.fullName || id}`);
    addToast(`Employee ${emp?.fullName || id} removed.`, 'info');
  };

  const toggleEmployeeStatus = (id) => {
    setEmployees(prev => prev.map(emp => {
      if (emp.id === id) {
        const nextStatus = emp.status === 'Active' ? 'Inactive' : 'Active';
        logAudit('Status Changed', 'Employees', `Changed ${emp.fullName} status to ${nextStatus}`);
        addToast(`Employee status changed to ${nextStatus}`, 'info');
        return { ...emp, status: nextStatus };
      }
      return emp;
    }));
    api.employees.toggleStatus(id).catch(() => {});
  };

  // =================== DEPARTMENTS CRUD ===================
  const addDepartment = (deptData) => {
    const newId = `DEP-0${departments.length + 1}`;
    const newDept = {
      id: newId,
      status: 'Active',
      employeeCount: 0,
      ...deptData
    };
    setDepartments(prev => [...prev, newDept]);
    api.departments.create(newDept).catch(() => {});
    logAudit('Department Created', 'Departments', `Created ${newDept.name} department`);
    addToast(`Department ${newDept.name} created!`, 'success');
  };

  const updateDepartment = (id, updatedFields) => {
    setDepartments(prev => prev.map(d => (d.id === id ? { ...d, ...updatedFields } : d)));
    api.departments.update(id, updatedFields).catch(() => {});
    logAudit('Department Updated', 'Departments', `Updated department ${id}`);
    addToast('Department updated successfully!', 'success');
  };

  const deleteDepartment = (id) => {
    const dept = departments.find(d => d.id === id);
    setDepartments(prev => prev.filter(d => d.id !== id));
    api.departments.delete(id).catch(() => {});
    logAudit('Department Deleted', 'Departments', `Deleted department ${dept?.name || id}`);
    addToast(`Department ${dept?.name || id} deleted.`, 'info');
  };

  // =================== PROJECTS CRUD ===================
  const addProject = (projectData) => {
    const newId = `PRJ-${100 + projects.length + 1}`;
    const newPrj = {
      id: newId,
      progress: 0,
      status: 'Planning',
      teamMembers: projectData.teamMembers || ['EMP-1004'],
      ...projectData
    };
    setProjects(prev => [newPrj, ...prev]);
    api.projects.create(newPrj).catch(() => {});
    logAudit('Project Created', 'Projects', `Created project: ${newPrj.name}`);
    triggerNotification('New Project Initiated', `Project ${newPrj.name} has been launched`, 'project', ['owner', 'manager']);
    addToast(`Project "${newPrj.name}" created!`, 'success');
  };

  const updateProject = (id, updatedFields) => {
    setProjects(prev => prev.map(p => (p.id === id ? { ...p, ...updatedFields } : p)));
    api.projects.update(id, updatedFields).catch(() => {});
    logAudit('Project Updated', 'Projects', `Updated project ${id}`);
    addToast('Project updated successfully!', 'success');
  };

  const deleteProject = (id) => {
    const prj = projects.find(p => p.id === id);
    setProjects(prev => prev.filter(p => p.id !== id));
    api.projects.delete(id).catch(() => {});
    logAudit('Project Deleted', 'Projects', `Deleted project ${prj?.name || id}`);
    addToast(`Project ${prj?.name || id} deleted.`, 'info');
  };

  // =================== TASKS CRUD ===================
  const createTask = (taskData) => {
    const newId = `TSK-${200 + tasks.length + 1}`;
    const nowTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const effectiveDept = taskData.department || (employees.find(e => e.fullName === taskData.assignedTo)?.department) || 'Engineering';
    const effectiveMgr = taskData.assignedManager || (employees.find(e => e.fullName === taskData.assignedTo)?.manager) || 'Marcus Sterling';
    const effectiveMgrObj = employees.find(e => e.fullName === effectiveMgr);

    const newTask = {
      id: newId,
      title: taskData.title || 'Untitled Task',
      description: taskData.description || '',
      assignedTo: taskData.assignedTo || 'Elena Rostova',
      assignedToId: taskData.assignedToId || 'EMP-1004',
      assignedManager: effectiveMgr,
      assignedManagerId: taskData.assignedManagerId || effectiveMgrObj?.id || 'EMP-1003',
      department: effectiveDept,
      project: taskData.project || 'Next-Gen Mobile App Overhaul',
      projectId: taskData.projectId || 'PRJ-102',
      priority: taskData.priority || 'Medium',
      status: taskData.status || 'Pending',
      startDate: taskData.startDate || CURRENT_DATE_REF,
      dueDate: taskData.dueDate || '2026-10-18',
      completionDate: taskData.status === 'Completed' ? CURRENT_DATE_REF : null,
      estimatedHours: Number(taskData.estimatedHours) || 16,
      actualHours: Number(taskData.actualHours) || 0,
      attachments: taskData.attachments || [],
      comments: taskData.comments || [],
      activityTimeline: [
        {
          id: `ACT-${Date.now()}-1`,
          action: `Task created and assigned to ${taskData.assignedTo || 'Elena Rostova'}`,
          user: currentUser?.name || 'Marcus Sterling',
          timestamp: `${CURRENT_DATE_REF} ${nowTimeStr}`
        }
      ],
      createdBy: currentUser?.name || 'Marcus Sterling',
      createdDate: CURRENT_DATE_REF
    };

    setTasks(prev => [newTask, ...prev]);
    api.tasks.create(newTask).catch(() => {});
    logAudit('Task Created', 'Tasks', `Created task "${newTask.title}" (${newTask.id}) assigned to ${newTask.assignedTo}`);
    triggerNotification(
      'New Task Assigned',
      `You have been assigned: "${newTask.title}" for ${newTask.project}`,
      'task',
      ['employee', 'manager'],
      '/employee/tasks'
    );
    addToast(`Task "${newTask.title}" created successfully!`, 'success');
    return newTask;
  };

  const addTask = createTask;

  const updateTask = (id, updatedFields) => {
    const nowTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        const newTimeline = [...(t.activityTimeline || [])];
        newTimeline.push({
          id: `ACT-${Date.now()}`,
          action: `Task details updated`,
          user: currentUser?.name || 'System',
          timestamp: `${CURRENT_DATE_REF} ${nowTimeStr}`
        });
        return { ...t, ...updatedFields, activityTimeline: newTimeline };
      }
      return t;
    }));
    api.tasks.update(id, updatedFields).catch(() => {});
    logAudit('Task Updated', 'Tasks', `Updated details for task ${id}`);
    addToast('Task updated successfully!', 'success');
  };

  const updateTaskStatus = (id, newStatus) => {
    const nowTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    let updatedTask = null;

    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        const isCompleted = newStatus === 'Completed';
        const updated = {
          ...t,
          status: newStatus,
          completionDate: isCompleted ? (t.completionDate || CURRENT_DATE_REF) : null,
          actualHours: (isCompleted && (!t.actualHours || t.actualHours === 0)) ? (t.estimatedHours || 16) : t.actualHours,
          activityTimeline: [
            ...(t.activityTimeline || []),
            {
              id: `ACT-${Date.now()}`,
              action: `Status changed to ${newStatus}`,
              user: currentUser?.name || t.assignedTo || 'Employee',
              timestamp: `${CURRENT_DATE_REF} ${nowTimeStr}`
            }
          ]
        };
        updatedTask = updated;
        return updated;
      }
      return t;
    }));

    if (updatedTask) {
      api.tasks.updateStatus(id, newStatus).catch(() => {});
      logAudit('Task Status Changed', 'Tasks', `Moved "${updatedTask.title}" (${id}) to ${newStatus}`);
      if (newStatus === 'Completed') {
        triggerNotification(
          'Task Completed',
          `"${updatedTask.title}" was marked as Completed by ${currentUser?.name || updatedTask.assignedTo}`,
          'task',
          ['manager', 'owner', 'hr']
        );
      }
      addToast(`Task status updated to "${newStatus}"!`, 'success');
    }
  };

  const addTaskComment = (id, text) => {
    if (!text || !text.trim()) return;
    const nowTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const authorName = currentUser?.name || 'Elena Rostova';
    const authorRole = currentUser?.role === 'manager' ? 'Manager' : currentUser?.role === 'owner' ? 'Owner' : currentUser?.role === 'hr' ? 'HR' : 'Employee';
    const avatar = currentUser?.avatar || 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150';

    const newComment = {
      id: `CMT-${Date.now()}`,
      author: authorName,
      authorRole,
      avatar,
      text: text.trim(),
      timestamp: `${CURRENT_DATE_REF} ${nowTimeStr}`
    };

    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        return {
          ...t,
          comments: [...(t.comments || []), newComment],
          activityTimeline: [
            ...(t.activityTimeline || []),
            {
              id: `ACT-${Date.now()}`,
              action: `Added comment: "${text.trim().slice(0, 35)}..."`,
              user: authorName,
              timestamp: `${CURRENT_DATE_REF} ${nowTimeStr}`
            }
          ]
        };
      }
      return t;
    }));

    api.tasks.addComment(id, text.trim(), authorName, authorRole, avatar).catch(() => {});
    addToast('Comment added.', 'success');
  };

  const updateTaskHours = (id, actualHours) => {
    setTasks(prev => prev.map(t => (t.id === id ? { ...t, actualHours: Number(actualHours) } : t)));
    api.tasks.updateHours(id, actualHours).catch(() => {});
    addToast('Hours updated.', 'info');
  };

  const deleteTask = (id) => {
    const t = tasks.find(x => x.id === id);
    setTasks(prev => prev.filter(x => x.id !== id));
    api.tasks.delete(id).catch(() => {});
    logAudit('Task Deleted', 'Tasks', `Deleted task ${t?.title || id}`);
    addToast('Task deleted successfully.', 'info');
  };

  // =================== WIFI GEOFENCE & ATTENDANCE ===================
  const getWifiNetworkInfo = (ssid) => {
    if (!ssid) return null;
    return companyWifis.find(w => w.ssid.toLowerCase() === ssid.toLowerCase());
  };

  const isNetworkAuthorized = (ssid) => {
    if (!ssid) return false;
    const match = getWifiNetworkInfo(ssid);
    // Must be a registered company WiFi AND attendanceEnabled must be true
    return Boolean(match && match.attendanceEnabled !== false);
  };

  const isCurrentWifiAuthorized = () => {
    return isNetworkAuthorized(currentNetwork?.ssid);
  };

  const toggleWifiAttendance = (wifiId, enableAttendance) => {
    let updatedWifi = null;
    setCompanyWifis(prev => prev.map(w => {
      if (w.id === wifiId) {
        const newStatus = enableAttendance !== undefined ? enableAttendance : !w.attendanceEnabled;
        updatedWifi = { ...w, attendanceEnabled: newStatus };
        return updatedWifi;
      }
      return w;
    }));

    if (updatedWifi) {
      api.wifis.toggleAttendance(wifiId, updatedWifi.attendanceEnabled).catch(() => {});
      const isAllowed = updatedWifi.attendanceEnabled;
      logAudit(
        'WiFi Policy Updated',
        'Settings',
        `Admin updated attendance permission for "${updatedWifi.ssid}" (${updatedWifi.location}) to: ${isAllowed ? 'ALLOWED' : 'DISABLED'}`
      );
      if (isAllowed) {
        addToast(`Attendance permission ENABLED for "${updatedWifi.ssid}". Employees on this WiFi can now mark attendance.`, 'success');
      } else {
        addToast(`Attendance permission DISABLED for "${updatedWifi.ssid}". Shift check-ins on this network are now restricted.`, 'warning');
      }
    }
  };

  const switchNetwork = (target) => {
    let net = target;
    if (typeof target === 'string') {
      net = AVAILABLE_SIMULATION_NETWORKS.find(n => n.ssid === target) || {
        ssid: target,
        label: target,
        location: 'Custom Network',
        ip: '192.168.0.50',
        bssid: '00:11:22:33:44:55',
        security: 'WPA2',
        isCompanyWifi: Boolean(getWifiNetworkInfo(target)),
        signalStrength: 75,
        speedMbps: 100,
        type: 'custom'
      };
    }
    const isCompany = Boolean(getWifiNetworkInfo(net.ssid));
    const isAuth = isNetworkAuthorized(net.ssid);
    const updatedNet = { ...net, isCompanyWifi: isCompany, attendanceAllowed: isAuth };
    setCurrentNetwork(updatedNet);
    logAudit('Network Switched', 'Security', `Device switched WiFi connection to "${net.ssid}" (${isAuth ? 'Authorized Office WiFi' : isCompany ? 'Company WiFi (Attendance Disabled by Admin)' : 'External/Unauthorized Network'})`);
    if (isAuth) {
      addToast(`Connected to Company WiFi "${net.ssid}". Attendance access authorized!`, 'success');
    } else if (isCompany) {
      addToast(`Connected to Company WiFi "${net.ssid}". Note: Admin has disabled attendance on this network.`, 'warning');
    } else {
      addToast(`Connected to "${net.ssid}". Attendance restricted to official office WiFi.`, 'warning');
    }
    return updatedNet;
  };

  const addCompanyWifi = (wifiData) => {
    const newId = `WIFI-${Date.now().toString().slice(-4)}`;
    const newWifi = {
      id: newId,
      ssid: wifiData.ssid.trim(),
      location: wifiData.location || 'Branch Office',
      ipRange: wifiData.ipRange || '192.168.1.0/24',
      security: wifiData.security || 'WPA3 Enterprise',
      isPrimary: false,
      speed: wifiData.speed || '500 Mbps',
      attendanceEnabled: wifiData.attendanceEnabled !== undefined ? wifiData.attendanceEnabled : true,
      description: wifiData.description || 'Configured by Administrator'
    };
    setCompanyWifis(prev => [...prev, newWifi]);
    api.wifis.create(newWifi).catch(() => {});
    logAudit('WiFi Config Added', 'Settings', `Authorized new company WiFi: ${newWifi.ssid} (${newWifi.location}) with Attendance: ${newWifi.attendanceEnabled ? 'Enabled' : 'Disabled'}`);
    addToast(`Company WiFi "${newWifi.ssid}" registered. Attendance is ${newWifi.attendanceEnabled ? 'ALLOWED' : 'DISABLED'}.`, 'success');
  };

  const deleteCompanyWifi = (id) => {
    const target = companyWifis.find(w => w.id === id);
    if (companyWifis.length <= 1) {
      addToast('Cannot delete the last remaining authorized office WiFi network!', 'warning');
      return;
    }
    setCompanyWifis(prev => prev.filter(w => w.id !== id));
    api.wifis.delete(id).catch(() => {});
    logAudit('WiFi Config Removed', 'Settings', `Revoked company WiFi: ${target?.ssid || id}`);
    addToast(`Company WiFi network removed.`, 'info');
  };

  const toggleWifiEnforcement = (enabled) => {
    setWifiEnforcementEnabled(enabled);
    logAudit('Security Policy Changed', 'Settings', `Office WiFi Attendance Restriction ${enabled ? 'Enforced' : 'Disabled'}`);
    addToast(`Office WiFi Attendance Enforcement ${enabled ? 'Enabled' : 'Disabled'}.`, 'info');
  };

  // =================== ATTENDANCE ===================
  const todayStr = '2026-10-01';
  const getTodayAttendanceForUser = (userId) => {
    return attendance.find(a => (a.employeeId === userId || a.employeeId === 'EMP-1004') && a.date === todayStr);
  };

  const checkInEmployee = (userId, userName, userDept) => {
    // 1. WiFi Enforcement Verification
    if (wifiEnforcementEnabled && !isCurrentWifiAuthorized()) {
      const currSsid = currentNetwork?.ssid || 'External Network';
      const companyInfo = getWifiNetworkInfo(currSsid);

      let errorMsg = `Attendance Blocked: You must connect to Company Office WiFi to mark attendance. (Current: "${currSsid}")`;
      if (companyInfo && companyInfo.attendanceEnabled === false) {
        errorMsg = `Attendance Blocked: Admin has disabled shift attendance on company WiFi "${currSsid}". Please connect to an authorized attendance WiFi.`;
      }

      addToast(errorMsg, 'error');
      logAudit(
        'Attendance Blocked',
        'Attendance',
        `${userName || 'Employee'} attempted check-in from network "${currSsid}" (${companyInfo ? 'Company WiFi disabled by Admin' : 'Unauthorized External Network'}). Denied by policy.`
      );
      return {
        success: false,
        reason: companyInfo ? 'WIFI_DISABLED_BY_ADMIN' : 'UNAUTHORIZED_WIFI',
        currentNetwork: currSsid,
        authorizedList: companyWifis.filter(w => w.attendanceEnabled !== false).map(w => w.ssid)
      };
    }

    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const existing = attendance.find(a => a.employeeId === (userId || 'EMP-1004') && a.date === todayStr);

    if (existing && existing.checkIn) {
      addToast('Already checked in for today!', 'warning');
      return { success: false, reason: 'ALREADY_CHECKED_IN' };
    }

    const newRecord = {
      id: `ATT-${Date.now().toString().slice(-4)}`,
      employeeId: userId || 'EMP-1004',
      employeeName: userName || 'Elena Rostova',
      department: userDept || 'Engineering',
      date: todayStr,
      checkIn: timeNow,
      checkOut: null,
      workHours: 0.1,
      status: 'Present',
      networkVerified: true,
      networkName: currentNetwork?.ssid || 'NEXORA-CORP-5G',
      networkIp: currentNetwork?.ip || '192.168.1.142',
      networkLocation: currentNetwork?.location || 'HQ Main Office'
    };

    setAttendance(prev => [newRecord, ...prev.filter(a => !(a.employeeId === newRecord.employeeId && a.date === todayStr))]);
    api.attendance.checkIn(newRecord).catch(() => {});
    logAudit('Check-In Verified', 'Attendance', `${newRecord.employeeName} checked in via Company WiFi (${newRecord.networkName} · ${newRecord.networkIp})`);
    addToast(`Checked in successfully at ${timeNow}! (Verified via ${newRecord.networkName})`, 'success');
    return { success: true, record: newRecord };
  };

  const checkOutEmployee = (userId) => {
    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const empId = userId || 'EMP-1004';

    setAttendance(prev => prev.map(a => {
      if (a.employeeId === empId && a.date === todayStr) {
        return {
          ...a,
          checkOut: timeNow,
          workHours: Math.max(a.workHours || 4.5, 8.2)
        };
      }
      return a;
    }));

    api.attendance.checkOut({ employeeId: empId, date: todayStr }).catch(() => {});
    logAudit('Check-Out', 'Attendance', `Employee checked out at ${timeNow}`);
    addToast(`Checked out successfully at ${timeNow}! Total hours logged.`, 'success');
  };

  const resetEmployeeAttendance = (userId) => {
    const empId = userId || 'EMP-1004';
    setAttendance(prev => prev.map(a => {
      if ((a.employeeId === empId || a.employeeId === 'EMP-1004' || a.id === 'ATT-301') && a.date === todayStr) {
        return {
          ...a,
          checkIn: null,
          checkOut: null,
          workHours: 0,
          status: 'Absent'
        };
      }
      return a;
    }));
    api.attendance.reset({ employeeId: empId, date: todayStr }).catch(() => {});
    logAudit('Attendance Reset', 'Attendance', `Reset attendance for employee ${empId} to test check-in.`);
    addToast('Attendance reset! Check In button is now available.', 'info');
  };

  // =================== ADMIN WFH ID AUTHORIZATION ===================
  const isEmployeeWFHAuthorized = (empId) => {
    if (!empId) return false;
    const cleanId = String(empId).trim().toUpperCase();
    return wfhAuthorizedEmployees.some(
      a => (a.employeeId?.toUpperCase() === cleanId || a.employeeName?.toLowerCase() === String(empId).trim().toLowerCase()) && a.status === 'Authorized'
    );
  };

  const getEmployeeWFHAuthInfo = (empId) => {
    if (!empId) return null;
    const cleanId = String(empId).trim().toUpperCase();
    return wfhAuthorizedEmployees.find(
      a => (a.employeeId?.toUpperCase() === cleanId || a.employeeName?.toLowerCase() === String(empId).trim().toLowerCase()) && a.status === 'Authorized'
    );
  };

  const authorizeEmployeeWFH = ({ employeeId, reason, validUntil, notes }) => {
    const cleanId = String(employeeId || '').trim();
    const emp = employees.find(
      e => e.id?.toUpperCase() === cleanId.toUpperCase() || e.fullName.toLowerCase() === cleanId.toLowerCase()
    );

    if (!emp) {
      addToast(`Employee with ID or name "${employeeId}" not found in employee directory.`, 'error');
      return { success: false, reason: 'EMPLOYEE_NOT_FOUND' };
    }

    const existing = wfhAuthorizedEmployees.find(a => a.employeeId === emp.id);
    const newAuth = {
      id: existing?.id || `WFH-AUTH-${Date.now().toString().slice(-4)}`,
      employeeId: emp.id,
      employeeName: emp.fullName,
      department: emp.department,
      designation: emp.designation,
      authorizedBy: `Administrator (${currentUser?.name || 'Saurabh Kumar'})`,
      authorizedDate: new Date().toISOString().split('T')[0],
      validUntil: validUntil || '2026-10-31',
      status: 'Authorized',
      reason: reason || 'Approved Remote Assignment',
      idCardVerified: true,
      notes: notes || 'Admin ID verified & authorized for remote shift attendance'
    };

    setWfhAuthorizedEmployees(prev => {
      const rest = prev.filter(a => a.employeeId !== emp.id);
      return [newAuth, ...rest];
    });

    api.attendance.authorizeWFH(newAuth).catch(() => {});

    logAudit(
      'WFH ID Authorized',
      'Administration',
      `Admin authorized Employee ID "${emp.id}" (${emp.fullName}) for Work From Home. HR can now mark remote attendance.`
    );

    triggerNotification(
      'WFH ID Authorized by Admin',
      `Administrator has authorized ${emp.fullName} (${emp.id}) for Work From Home. HR can now mark remote attendance.`,
      'attendance',
      ['hr', 'owner', 'manager'],
      '/hr/attendance'
    );

    addToast(`Employee ID "${emp.id}" (${emp.fullName}) successfully authorized for WFH by Admin!`, 'success');
    return { success: true, record: newAuth };
  };

  const revokeEmployeeWFH = (empId) => {
    const target = wfhAuthorizedEmployees.find(a => a.employeeId === empId);
    setWfhAuthorizedEmployees(prev => prev.filter(a => a.employeeId !== empId));
    api.attendance.revokeWFH(empId).catch(() => {});

    logAudit(
      'WFH ID Revoked',
      'Administration',
      `Admin revoked Work From Home authorization for Employee ID "${empId}" (${target?.employeeName || 'Staff'}).`
    );

    addToast(`WFH Authorization for ID "${empId}" has been revoked by Admin.`, 'info');
  };

  const markWFHAttendance = ({
    employeeId,
    date = todayStr,
    checkIn = '09:00 AM',
    checkOut = null,
    status = 'Present',
    workHours = 8.0,
    notes = 'Authorized Work From Home'
  }) => {
    const emp = employees.find(e => e.id === employeeId || e.fullName.toLowerCase() === (employeeId || '').toLowerCase());
    if (!emp) {
      addToast(`Employee with ID or name "${employeeId}" not found.`, 'error');
      return { success: false, reason: 'EMPLOYEE_NOT_FOUND' };
    }

    // Verify Admin Authorization for this ID
    const authRecord = getEmployeeWFHAuthInfo(emp.id);
    if (!authRecord) {
      addToast(
        `Attendance Denied: Employee ID "${emp.id}" (${emp.fullName}) is not authorized for Work From Home by Admin. Admin must authorize this ID card first!`,
        'error'
      );
      return {
        success: false,
        reason: 'NOT_AUTHORIZED_BY_ADMIN',
        message: `Employee ID "${emp.id}" is not authorized for WFH by Administrator.`
      };
    }

    const effectiveDate = date || todayStr;
    const existing = attendance.find(a => (a.employeeId === emp.id || a.employeeName === emp.fullName) && a.date === effectiveDate);
    const calculatedHours = checkOut ? Number(workHours || 8.5) : (status === 'Late' ? 7.0 : 8.0);

    const wfhRecord = {
      id: existing?.id || `ATT-WFH-${Date.now().toString().slice(-4)}`,
      employeeId: emp.id,
      employeeName: emp.fullName,
      department: emp.department,
      date: effectiveDate,
      checkIn: checkIn || '09:00 AM',
      checkOut: checkOut || (status === 'Present' || status === 'Late' ? '05:30 PM' : null),
      workHours: calculatedHours,
      status: status || 'Present',
      isWFH: true,
      workMode: 'Work From Home',
      adminAuthorized: true,
      adminAuthId: authRecord.id,
      adminAuthReason: authRecord.reason,
      networkVerified: true,
      networkName: 'Work From Home (Admin ID Authorized)',
      networkLocation: 'Remote · Home Office',
      networkIp: '192.168.1.1 (Remote VPN)',
      markedBy: `HR (${currentUser?.name || 'Sophia Montgomery'})`,
      markedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      notes: notes || `WFH Approved by Admin (${authRecord.id}) & Marked by HR`
    };

    setAttendance(prev => {
      const filtered = prev.filter(a => !( (a.employeeId === emp.id || a.employeeName === emp.fullName) && a.date === effectiveDate));
      return [wfhRecord, ...filtered];
    });

    api.attendance.markWFH(wfhRecord).catch(() => {});

    logAudit(
      'WFH Attendance Marked',
      'Attendance',
      `HR (${currentUser?.name || 'Sophia Montgomery'}) marked Work From Home attendance for Admin-authorized ID ${emp.id} (${emp.fullName}) on ${effectiveDate} as ${status}.`
    );

    triggerNotification(
      'Work From Home Attendance Marked',
      `HR has marked your Work From Home (WFH) attendance for ${effectiveDate} as ${status} (Admin Auth: ${authRecord.id}).`,
      'attendance',
      ['employee'],
      '/employee/attendance'
    );

    addToast(`WFH Attendance for ${emp.fullName} (${emp.id}) marked as ${status} (Admin ID Verified)!`, 'success');
    return { success: true, record: wfhRecord };
  };

  // =================== DIGITAL ID CARD GENERATION & HR APPROVAL ===================
  const getEmployeeIDCard = (empId) => {
    if (!empId) return null;
    return idCardRequests.find(r => r.employeeId === empId) || null;
  };

  const requestIDCard = ({
    employeeId,
    bloodGroup = 'O+',
    emergencyContact = '',
    reason = 'Initial Employee Digital ID Card Generation',
    cardType = 'Corporate Staff Badge',
    customPhoto = null
  }) => {
    const emp = employees.find(e => e.id === employeeId || e.email === employeeId);
    if (!emp) {
      addToast(`Employee record not found for ID "${employeeId}".`, 'error');
      return { success: false, message: 'Employee not found' };
    }

    const existing = idCardRequests.find(r => r.employeeId === emp.id);
    const newReqId = existing?.id || `REQ-ID-${Date.now().toString().slice(-4)}`;

    const newRequest = {
      id: newReqId,
      employeeId: emp.id,
      employeeName: emp.fullName,
      department: emp.department,
      designation: emp.designation,
      avatar: customPhoto || emp.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      bloodGroup: bloodGroup || emp.bloodGroup || 'O+',
      emergencyContact: emergencyContact || emp.emergencyContact || '+1 (555) 000-0000',
      requestDate: todayStr,
      reason: reason || 'Initial Employee Digital ID Card Generation',
      cardType: cardType || 'Corporate Staff Badge',
      status: 'Pending',
      badgeNumber: existing?.status === 'Approved' ? existing.badgeNumber : null,
      issuedDate: null,
      validUntil: null,
      approvedBy: null,
      notes: 'Awaiting HR verification and digital badge authorization.',
      qrCodeData: `NEXORA-PENDING-${emp.id}-${newReqId}`
    };

    setIdCardRequests(prev => {
      const rest = prev.filter(r => r.employeeId !== emp.id);
      return [newRequest, ...rest];
    });

    api.idCards.request(newRequest).catch(() => {});

    logAudit(
      'ID Card Requested',
      'ID Card Operations',
      `${emp.fullName} (${emp.id}) submitted request for digital ID card generation (${cardType}).`
    );

    triggerNotification(
      'New ID Card Generation Request',
      `${emp.fullName} (${emp.id}) requested digital ID card generation. Awaiting HR review.`,
      'id_card',
      ['hr', 'admin', 'owner'],
      '/hr/id-cards'
    );

    addToast(`ID Card generation request submitted for ${emp.fullName}! Awaiting HR approval.`, 'success');
    return { success: true, request: newRequest };
  };

  const approveIDCardRequest = (requestId, approvalNotes = '') => {
    const target = idCardRequests.find(r => r.id === requestId);
    if (!target) {
      addToast('ID Card request not found.', 'error');
      return { success: false };
    }

    const badgeNum = target.badgeNumber || `NEX-ID-${Math.floor(10000 + Math.random() * 90000)}`;
    const approverName = currentUser?.name ? `${currentUser.name} (${currentUser.title || 'HR Operations'})` : 'Sophia Montgomery (VP of HR)';

    const updated = {
      ...target,
      status: 'Approved',
      badgeNumber: badgeNum,
      issuedDate: todayStr,
      validUntil: '2028-10-08',
      approvedBy: approverName,
      approvalDate: todayStr,
      notes: approvalNotes || 'Official ID credentials verified and authorized by HR Operations.',
      qrCodeData: `NEXORA-VERIFIED-${target.employeeId}-SECURE-${badgeNum}`
    };

    setIdCardRequests(prev => prev.map(r => r.id === requestId ? updated : r));
    api.idCards.approve(requestId, { approvedBy: approverName, notes: approvalNotes }).catch(() => {});

    logAudit(
      'ID Card Approved',
      'ID Card Operations',
      `HR approved ID card request for ${target.employeeName} (${target.employeeId}). Badge ${badgeNum} issued.`
    );

    triggerNotification(
      'ID Card Approved & Issued! 🎉',
      `Your official digital employee ID card has been approved by HR! Badge Number: ${badgeNum}.`,
      'id_card',
      ['employee'],
      '/employee/id-card'
    );

    addToast(`ID Card request for ${target.employeeName} approved! Badge ${badgeNum} issued.`, 'success');
    return { success: true, request: updated };
  };

  const rejectIDCardRequest = (requestId, rejectionReason = '') => {
    const target = idCardRequests.find(r => r.id === requestId);
    if (!target) {
      addToast('ID Card request not found.', 'error');
      return { success: false };
    }

    const reasonText = rejectionReason || 'Information mismatch or unclear photo. Please verify details and reapply.';
    const reviewerName = currentUser?.name || 'HR Operations';

    const updated = {
      ...target,
      status: 'Rejected',
      rejectedBy: reviewerName,
      rejectionDate: todayStr,
      rejectionReason: reasonText,
      notes: reasonText
    };

    setIdCardRequests(prev => prev.map(r => r.id === requestId ? updated : r));
    api.idCards.reject(requestId, { rejectedBy: reviewerName, reason: reasonText }).catch(() => {});

    logAudit(
      'ID Card Rejected',
      'ID Card Operations',
      `HR declined ID card request for ${target.employeeName} (${target.employeeId}): ${reasonText}`
    );

    triggerNotification(
      'ID Card Request Declined',
      `Your ID card generation request was declined by HR: "${reasonText}". Please review and reapply.`,
      'id_card',
      ['employee'],
      '/employee/id-card'
    );

    addToast(`ID Card request for ${target.employeeName} declined.`, 'info');
    return { success: true, request: updated };
  };

  const adminGenerateIDCard = ({
    employeeId,
    bloodGroup = 'O+',
    emergencyContact = '',
    badgeNumber = null,
    validUntil = '2028-10-08',
    cardType = 'Corporate Staff Badge',
    notes = 'Official Root Administrator Direct Credential Issuance',
    customPhoto = null
  }) => {
    const emp = employees.find(e => e.id === employeeId || e.email === employeeId);
    if (!emp) {
      addToast(`Employee record not found for "${employeeId}".`, 'error');
      return { success: false, message: 'Employee not found' };
    }

    const assignedBadgeNum = badgeNumber || `NEX-ID-${Math.floor(10000 + Math.random() * 90000)}`;
    const approverTitle = currentUser?.title || 'System Administrator';
    const approverName = currentUser?.name ? `${currentUser.name} (${approverTitle})` : 'Administrator (Saurabh Kumar)';

    const approvedByStr = approverName;
    const newApprovedCard = {
      id: `REQ-ID-${Date.now().toString().slice(-4)}`,
      employeeId: emp.id,
      employeeName: emp.fullName,
      department: emp.department,
      designation: emp.designation,
      avatar: customPhoto || emp.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      bloodGroup: bloodGroup || emp.bloodGroup || 'O+',
      emergencyContact: emergencyContact || emp.emergencyContact || '+1 (555) 999-1122',
      requestDate: todayStr,
      reason: 'Root Administrator Direct Credential Issuance',
      cardType: cardType || 'Corporate Staff Badge',
      status: 'Approved',
      badgeNumber: assignedBadgeNum,
      issuedDate: todayStr,
      validUntil: validUntil || '2028-10-08',
      approvedBy: approverName,
      approvalDate: todayStr,
      notes: notes || 'Direct Administrator security clearance and immediate badge authorization.',
      qrCodeData: `NEXORA-ADMIN-VERIFIED-${emp.id}-SECURE-${assignedBadgeNum}`
    };

    setIdCardRequests(prev => {
      const rest = prev.filter(r => r.employeeId !== emp.id);
      return [newApprovedCard, ...rest];
    });

    api.idCards.adminIssue({
      employeeId: emp.id,
      employeeName: emp.fullName,
      department: emp.department,
      designation: emp.designation,
      badgeNumber: assignedBadgeNum,
      approvedBy: approvedByStr,
      notes
    }).catch(() => {});

    logAudit(
      'Admin ID Card Issued',
      'ID Card Operations',
      `Administrator directly issued official ID card badge ${assignedBadgeNum} for ${emp.fullName} (${emp.id}).`
    );

    triggerNotification(
      'Official ID Badge Issued by Administrator 🛡️',
      `Administrator has directly issued and approved your official digital employee badge (Serial: ${assignedBadgeNum}).`,
      'id_card',
      ['employee'],
      '/employee/id-card'
    );

    addToast(`Official ID Card directly issued for ${emp.fullName} (${emp.id}) with Badge ${assignedBadgeNum}!`, 'success');
    return { success: true, card: newApprovedCard };
  };

  // =================== LEAVES ===================
  const applyLeave = (leaveData) => {
    const newId = `LEV-${500 + leaves.length + 1}`;
    const newLeave = {
      id: newId,
      employeeId: currentUser?.id === 'USR-004' ? 'EMP-1004' : (currentUser?.id || 'EMP-1004'),
      employeeName: currentUser?.name || 'Elena Rostova',
      department: currentUser?.department || 'Engineering',
      status: 'Pending',
      appliedOn: todayStr,
      approver: 'Marcus Sterling',
      remarks: '',
      ...leaveData
    };
    setLeaves(prev => [newLeave, ...prev]);
    api.leaves.apply(newLeave).catch(() => {});
    logAudit('Leave Applied', 'Leave Management', `${newLeave.employeeName} applied for ${newLeave.leaveType} (${newLeave.days} days)`);
    triggerNotification('New Leave Application', `${newLeave.employeeName} submitted a leave request`, 'leave', ['manager', 'hr', 'owner'], '/manager/leave');
    addToast('Leave request submitted successfully!', 'success');
  };

  const approveLeave = (leaveId, remarks = '') => {
    setLeaves(prev => prev.map(l => {
      if (l.id === leaveId) {
        logAudit('Leave Approved', 'Leave Management', `Approved leave ${leaveId} for ${l.employeeName}`);
        triggerNotification('Leave Approved', `Your leave request from ${l.startDate} to ${l.endDate} was approved!`, 'leave', ['employee'], '/employee/leave');
        return { ...l, status: 'Approved', remarks: remarks || 'Approved by Manager' };
      }
      return l;
    }));
    api.leaves.approve(leaveId, remarks || 'Approved by Manager').catch(() => {});
    addToast('Leave request approved!', 'success');
  };

  const rejectLeave = (leaveId, remarks = '') => {
    setLeaves(prev => prev.map(l => {
      if (l.id === leaveId) {
        logAudit('Leave Rejected', 'Leave Management', `Rejected leave ${leaveId} for ${l.employeeName}`);
        triggerNotification('Leave Request Update', `Your leave request for ${l.startDate} was not approved.`, 'leave', ['employee'], '/employee/leave');
        return { ...l, status: 'Rejected', remarks: remarks || 'Declined due to scheduling constraints.' };
      }
      return l;
    }));
    api.leaves.reject(leaveId, remarks || 'Declined due to scheduling constraints.').catch(() => {});
    addToast('Leave request rejected.', 'info');
  };

  // =================== PAYROLL ===================
  const markPayrollPaid = (id) => {
    setPayroll(prev => prev.map(p => (p.id === id ? { ...p, status: 'Paid', paymentDate: todayStr } : p)));
    api.payroll.markPaid(id).catch(() => {});
    logAudit('Payroll Disbursed', 'Payroll', `Marked payslip ${id} as Paid`);
    addToast('Payroll record marked as Paid!', 'success');
  };

  // =================== ANNOUNCEMENTS ===================
  const addAnnouncement = (data) => {
    const newId = `ANC-${800 + announcements.length + 1}`;
    const newAnc = {
      id: newId,
      date: todayStr,
      author: currentUser?.name || 'Saurabh Kumar',
      authorRole: currentUser?.title || 'Executive',
      pinned: false,
      readBy: [],
      ...data
    };
    setAnnouncements(prev => [newAnc, ...prev]);
    api.announcements.create(newAnc).catch(() => {});
    logAudit('Announcement Published', 'Announcements', `Published: "${newAnc.title}"`);
    triggerNotification('New Announcement', newAnc.title, 'announcement', ['owner', 'hr', 'manager', 'employee'], '/employee/announcements');
    addToast('Announcement published successfully!', 'success');
  };

  const togglePinAnnouncement = (id) => {
    setAnnouncements(prev => prev.map(a => (a.id === id ? { ...a, pinned: !a.pinned } : a)));
    api.announcements.togglePin(id).catch(() => {});
  };

  const deleteAnnouncement = (id) => {
    setAnnouncements(prev => prev.filter(a => a.id !== id));
    api.announcements.delete(id).catch(() => {});
    logAudit('Announcement Deleted', 'Announcements', `Deleted announcement ${id}`);
    addToast('Announcement deleted.', 'info');
  };

  const markAnnouncementRead = (id, userId) => {
    const uid = userId || currentUser?.id || 'EMP-1004';
    setAnnouncements(prev => prev.map(a => {
      if (a.id === id && !a.readBy.includes(uid)) {
        return { ...a, readBy: [...a.readBy, uid] };
      }
      return a;
    }));
    api.announcements.markRead(id, uid).catch(() => {});
  };

  // =================== RECRUITMENT ===================
  const moveCandidateStage = (candidateId, newStage) => {
    setCandidates(prev => prev.map(c => {
      if (c.id === candidateId) {
        logAudit('Candidate Stage Moved', 'Recruitment', `Moved candidate ${c.name} to ${newStage}`);
        return { ...c, stage: newStage };
      }
      return c;
    }));
    api.recruitment.updateStage(candidateId, newStage).catch(() => {});
    addToast(`Candidate moved to ${newStage}`, 'info');
  };

  const addJobOpening = (jobData) => {
    const newId = `JOB-${400 + jobOpenings.length + 1}`;
    const newJob = {
      id: newId,
      status: 'Open',
      postedDate: todayStr,
      applicantsCount: 0,
      ...jobData
    };
    setJobOpenings(prev => [newJob, ...prev]);
    api.recruitment.createJob(newJob).catch(() => {});
    logAudit('Job Opening Created', 'Recruitment', `Created opening for ${newJob.title}`);
    addToast(`Job opening "${newJob.title}" created!`, 'success');
  };

  const addCandidate = (candData) => {
    const newId = `CND-${700 + candidates.length + 1}`;
    const newCand = {
      id: newId,
      stage: 'Applied',
      appliedDate: todayStr,
      rating: 4.0,
      ...candData
    };
    setCandidates(prev => [newCand, ...prev]);
    setJobOpenings(prev => prev.map(j => j.id === newCand.jobId ? { ...j, applicantsCount: j.applicantsCount + 1 } : j));
    api.recruitment.createCandidate(newCand).catch(() => {});
    logAudit('Candidate Added', 'Recruitment', `Added candidate ${newCand.name}`);
    addToast(`Candidate ${newCand.name} registered!`, 'success');
  };

  // =================== PERFORMANCE ===================
  const addPerformanceReview = (reviewData) => {
    const newId = `PRF-${600 + performanceReviews.length + 1}`;
    const newReview = {
      id: newId,
      status: 'Reviewed',
      date: todayStr,
      ...reviewData
    };
    setPerformanceReviews(prev => [newReview, ...prev]);
    api.performance.create(newReview).catch(() => {});
    logAudit('Performance Review Added', 'Performance', `Reviewed employee ${newReview.employeeName}`);
    triggerNotification('Performance Review Available', `Review for ${newReview.reviewPeriod} has been published`, 'performance', ['employee'], '/employee/performance');
    addToast('Performance review submitted!', 'success');
  };

  // =================== NOTIFICATIONS ===================
  const markNotificationRead = (id) => {
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
    api.notifications.markRead(id).catch(() => {});
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    api.notifications.markAllRead().catch(() => {});
    addToast('All notifications marked as read', 'info');
  };

  const deleteNotification = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
    api.notifications.delete(id).catch(() => {});
  };

  // =================== INVENTORY MANAGEMENT ===================
  const calculateProductStatus = (qty, threshold) => {
    const q = Number(qty) || 0;
    const t = Number(threshold) || 10;
    if (q <= 0) return 'Out of Stock';
    if (q <= t) return 'Low Stock';
    return 'In Stock';
  };

  const addInventoryProduct = (productData) => {
    const newId = `PRD-${Date.now().toString().slice(-4)}`;
    const sku = productData.sku || `SKU-${Date.now().toString().slice(-4)}`;
    const quantity = Number(productData.quantity) || 0;
    const minThreshold = Number(productData.minThreshold) || 10;
    const status = calculateProductStatus(quantity, minThreshold);

    const newProduct = {
      id: newId,
      sku,
      status,
      lastRestocked: todayStr,
      ...productData,
      quantity,
      minThreshold,
      costPrice: Number(productData.costPrice) || 0,
      sellingPrice: Number(productData.sellingPrice) || 0
    };

    setInventoryProducts(prev => [newProduct, ...prev]);

    if (quantity > 0) {
      const initMovement = {
        id: `MOV-${Date.now().toString().slice(-5)}`,
        productId: newId,
        productName: newProduct.name,
        sku: newProduct.sku,
        type: 'IN',
        quantity: quantity,
        unitPrice: newProduct.costPrice,
        totalAmount: quantity * newProduct.costPrice,
        previousStock: 0,
        newStock: quantity,
        reason: 'Initial Inventory Intake',
        referenceNo: 'INIT-STOCK',
        performedBy: currentUser?.name || 'Administrator',
        timestamp: `${todayStr} 10:00 AM`,
        notes: 'Initial stock intake upon product registration'
      };
      setInventoryStockMovements(prev => [initMovement, ...prev]);
    }

    api.inventory.createProduct(newProduct).catch(() => {});
    logAudit('CREATE_PRODUCT', 'Inventory', `Created product ${newProduct.name} (${sku})`);
    triggerNotification('Product Added', `New item ${newProduct.name} cataloged with ${quantity} units`, 'inventory', ['owner', 'admin', 'manager'], '/admin/inventory');
    addToast(`Product "${newProduct.name}" created successfully!`, 'success');
    return newProduct;
  };

  const updateInventoryProduct = (id, updatedFields) => {
    setInventoryProducts(prev => prev.map(p => {
      if (p.id === id) {
        const qty = updatedFields.quantity !== undefined ? Number(updatedFields.quantity) : p.quantity;
        const thresh = updatedFields.minThreshold !== undefined ? Number(updatedFields.minThreshold) : p.minThreshold;
        const status = calculateProductStatus(qty, thresh);
        return {
          ...p,
          ...updatedFields,
          quantity: qty,
          minThreshold: thresh,
          status,
          costPrice: updatedFields.costPrice !== undefined ? Number(updatedFields.costPrice) : p.costPrice,
          sellingPrice: updatedFields.sellingPrice !== undefined ? Number(updatedFields.sellingPrice) : p.sellingPrice
        };
      }
      return p;
    }));
    api.inventory.updateProduct(id, updatedFields).catch(() => {});
    logAudit('UPDATE_PRODUCT', 'Inventory', `Updated product details for ${id}`);
    addToast('Product details updated successfully!', 'success');
  };

  const deleteInventoryProduct = (id) => {
    const prd = inventoryProducts.find(p => p.id === id);
    setInventoryProducts(prev => prev.filter(p => p.id !== id));
    api.inventory.deleteProduct(id).catch(() => {});
    logAudit('DELETE_PRODUCT', 'Inventory', `Removed product ${prd?.name || id}`);
    addToast(`Product ${prd?.name || id} removed from catalog`, 'info');
  };

  const performStockIn = ({ productId, quantity, reference, notes, unitCost, supplierName, performedBy }) => {
    const qty = Number(quantity);
    if (!productId || isNaN(qty) || qty <= 0) {
      addToast('Please enter a valid stock quantity', 'error');
      return false;
    }

    const prd = inventoryProducts.find(p => p.id === productId);
    if (!prd) {
      addToast('Product not found in catalog', 'error');
      return false;
    }

    const prevStock = prd.quantity;
    const newStock = prevStock + qty;
    const effectiveCost = Number(unitCost) || prd.costPrice;
    const status = calculateProductStatus(newStock, prd.minThreshold);

    setInventoryProducts(prev => prev.map(p => p.id === productId ? {
      ...p,
      quantity: newStock,
      status,
      lastRestocked: todayStr,
      costPrice: effectiveCost
    } : p));

    const movement = {
      id: `MOV-${Date.now().toString().slice(-5)}`,
      productId,
      productName: prd.name,
      sku: prd.sku,
      type: 'IN',
      quantity: qty,
      unitPrice: effectiveCost,
      totalAmount: qty * effectiveCost,
      previousStock: prevStock,
      newStock: newStock,
      reason: reference || 'Inbound Shipment / Restock',
      referenceNo: `IN-${Date.now().toString().slice(-4)}`,
      supplier: supplierName || prd.supplier || 'Primary Supplier',
      performedBy: performedBy || currentUser?.name || 'Administrator',
      timestamp: `${todayStr} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      notes: notes || 'Stock received into warehouse'
    };
    setInventoryStockMovements(prev => [movement, ...prev]);

    api.inventory.stockIn({
      productId,
      quantity: qty,
      reference,
      notes,
      unitCost: effectiveCost,
      supplierName,
      performedBy: performedBy || currentUser?.name || 'Administrator'
    }).catch(() => {});

    logAudit('STOCK_IN', 'Inventory', `Restocked +${qty} units of ${prd.name} (${prd.sku})`);
    triggerNotification('Stock Inward Received', `Restocked ${qty} units of ${prd.name}. Total stock: ${newStock}`, 'inventory', ['owner', 'admin', 'manager'], '/admin/inventory');
    addToast(`Successfully received ${qty} units of ${prd.name}!`, 'success');
    return true;
  };

  const performStockOut = ({ productId, quantity, reference, notes, destination, department, performedBy }) => {
    const qty = Number(quantity);
    if (!productId || isNaN(qty) || qty <= 0) {
      addToast('Please enter a valid stock quantity', 'error');
      return false;
    }

    const prd = inventoryProducts.find(p => p.id === productId);
    if (!prd) {
      addToast('Product not found in catalog', 'error');
      return false;
    }

    if (prd.quantity < qty) {
      addToast(`Insufficient stock! Available: ${prd.quantity}, Requested: ${qty}`, 'error');
      return false;
    }

    const prevStock = prd.quantity;
    const newStock = prevStock - qty;
    const status = calculateProductStatus(newStock, prd.minThreshold);

    setInventoryProducts(prev => prev.map(p => p.id === productId ? {
      ...p,
      quantity: newStock,
      status
    } : p));

    const movement = {
      id: `MOV-${Date.now().toString().slice(-5)}`,
      productId,
      productName: prd.name,
      sku: prd.sku,
      type: 'OUT',
      quantity: qty,
      unitPrice: prd.costPrice,
      totalAmount: qty * prd.costPrice,
      previousStock: prevStock,
      newStock: newStock,
      reason: reference || 'Stock Issuance / Dispatch',
      referenceNo: `OUT-${Date.now().toString().slice(-4)}`,
      destination: destination || department || 'Operations',
      department: department || 'General',
      performedBy: performedBy || currentUser?.name || 'Administrator',
      timestamp: `${todayStr} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      notes: notes || 'Stock dispatched for company use'
    };
    setInventoryStockMovements(prev => [movement, ...prev]);

    api.inventory.stockOut({
      productId,
      quantity: qty,
      reference,
      notes,
      destination,
      department,
      performedBy: performedBy || currentUser?.name || 'Administrator'
    }).catch(() => {});

    logAudit('STOCK_OUT', 'Inventory', `Dispatched -${qty} units of ${prd.name} to ${destination || department || 'Operations'}`);

    if (status === 'Low Stock' || status === 'Out of Stock') {
      triggerNotification('Low Stock Alert', `Warning: ${prd.name} is now ${status.toLowerCase()} (${newStock} remaining)`, 'inventory', ['owner', 'admin', 'manager'], '/admin/inventory');
    }

    addToast(`Successfully dispatched ${qty} units of ${prd.name}!`, 'success');
    return true;
  };

  const addInventorySupplier = (supplierData) => {
    const newId = `SUP-${Date.now().toString().slice(-4)}`;
    const newSupplier = {
      id: newId,
      status: 'Active',
      rating: 4.8,
      categories: ['IT Hardware'],
      totalOrders: 0,
      paymentTerms: 'Net 30',
      ...supplierData
    };
    setInventorySuppliers(prev => [newSupplier, ...prev]);
    api.inventory.createSupplier(newSupplier).catch(() => {});
    logAudit('CREATE_SUPPLIER', 'Inventory', `Created vendor ${newSupplier.name}`);
    addToast(`Supplier "${newSupplier.name}" added successfully!`, 'success');
    return newSupplier;
  };

  const updateInventorySupplier = (id, updatedFields) => {
    setInventorySuppliers(prev => prev.map(s => s.id === id ? { ...s, ...updatedFields } : s));
    api.inventory.updateSupplier(id, updatedFields).catch(() => {});
    logAudit('UPDATE_SUPPLIER', 'Inventory', `Updated supplier details for ${id}`);
    addToast('Supplier updated successfully!', 'success');
  };

  const deleteInventorySupplier = (id) => {
    const sup = inventorySuppliers.find(s => s.id === id);
    setInventorySuppliers(prev => prev.filter(s => s.id !== id));
    api.inventory.deleteSupplier(id).catch(() => {});
    logAudit('DELETE_SUPPLIER', 'Inventory', `Removed supplier ${sup?.name || id}`);
    addToast(`Supplier "${sup?.name || id}" removed`, 'info');
  };

  const createPurchaseOrder = (poData) => {
    const poNumber = `PO-2026-${Date.now().toString().slice(-4)}`;
    const items = poData.items || [];
    const totalAmount = items.reduce((sum, item) => sum + (Number(item.quantity) * Number(item.unitCost || 0)), 0);

    const newPO = {
      id: `PO-${Date.now().toString().slice(-4)}`,
      poNumber,
      orderDate: todayStr,
      expectedDelivery: poData.expectedDelivery || '2026-10-25',
      status: currentUser?.role === 'owner' || currentUser?.role === 'admin' ? 'Approved' : 'Pending',
      items,
      totalAmount,
      requestedBy: currentUser?.name || 'Administrator',
      notes: poData.notes || 'Procurement requisition',
      ...poData
    };

    setInventoryPurchaseOrders(prev => [newPO, ...prev]);
    api.inventory.createPurchaseOrder(newPO).catch(() => {});
    logAudit('CREATE_PO', 'Inventory', `Created Purchase Order ${poNumber} for ₹${totalAmount.toLocaleString('en-IN')}`);
    triggerNotification('New Purchase Order', `${poNumber} created for ₹${totalAmount.toLocaleString('en-IN')}`, 'inventory', ['owner', 'admin', 'manager'], '/admin/inventory');
    addToast(`Purchase Order ${poNumber} submitted!`, 'success');
    return newPO;
  };

  const updatePurchaseOrderStatus = (poId, newStatus) => {
    const po = inventoryPurchaseOrders.find(p => p.id === poId);
    if (!po) return;

    if (newStatus === 'Received' && po.status !== 'Received') {
      const nowTime = `${todayStr} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
      
      po.items.forEach(item => {
        const itemQty = Number(item.quantity) || 1;
        const matchingPrd = inventoryProducts.find(p => 
          (item.productId && p.id === item.productId) || 
          (item.sku && p.sku === item.sku) ||
          p.name.toLowerCase() === item.name.toLowerCase()
        );

        if (matchingPrd) {
          const prevStock = matchingPrd.quantity;
          const newStock = prevStock + itemQty;
          const status = calculateProductStatus(newStock, matchingPrd.minThreshold);

          setInventoryProducts(prev => prev.map(p => p.id === matchingPrd.id ? {
            ...p,
            quantity: newStock,
            status,
            lastRestocked: todayStr
          } : p));

          const mov = {
            id: `MOV-${Date.now().toString().slice(-5)}-${Math.floor(Math.random() * 100)}`,
            productId: matchingPrd.id,
            productName: matchingPrd.name,
            sku: matchingPrd.sku,
            type: 'IN',
            quantity: itemQty,
            unitPrice: Number(item.unitCost) || matchingPrd.costPrice,
            totalAmount: itemQty * (Number(item.unitCost) || matchingPrd.costPrice),
            previousStock: prevStock,
            newStock: newStock,
            reason: `Purchase Order Fulfillment (${po.poNumber})`,
            referenceNo: po.poNumber,
            supplier: po.supplierName || 'Procurement Vendor',
            performedBy: currentUser?.name || 'Administrator',
            timestamp: nowTime,
            notes: `Auto-stocked from received Purchase Order ${po.poNumber}`
          };
          setInventoryStockMovements(prev => [mov, ...prev]);
        }
      });

      api.inventory.receivePurchaseOrder(poId, { receivedBy: currentUser?.name || 'Administrator' }).catch(() => {});
      triggerNotification('PO Received & Stocked', `Purchase Order ${po.poNumber} marked as received. Stock quantities updated!`, 'inventory', ['owner', 'admin', 'manager'], '/admin/inventory');
    } else {
      api.inventory.updatePOStatus(poId, newStatus).catch(() => {});
    }

    setInventoryPurchaseOrders(prev => prev.map(p => p.id === poId ? {
      ...p,
      status: newStatus,
      receivedDate: newStatus === 'Received' ? todayStr : p.receivedDate
    } : p));

    logAudit('UPDATE_PO_STATUS', 'Inventory', `PO ${po.poNumber} status updated to ${newStatus}`);
    addToast(`Purchase Order ${po.poNumber} marked as ${newStatus}`, 'success');
  };

  return (
    <ERPContext.Provider value={{
      isBackendConnected,
      employees,
      addEmployee,
      updateEmployee,
      deleteEmployee,
      toggleEmployeeStatus,

      departments,
      addDepartment,
      updateDepartment,
      deleteDepartment,

      projects,
      addProject,
      updateProject,
      deleteProject,

      tasks,
      createTask,
      addTask,
      updateTask,
      updateTaskStatus,
      addTaskComment,
      updateTaskHours,
      deleteTask,
      calculateCompletionRate,
      calculateProductivityScore,
      getEffectiveStatus,
      currentDateRef: CURRENT_DATE_REF,

      attendance,
      checkInEmployee,
      checkOutEmployee,
      resetEmployeeAttendance,
      getTodayAttendanceForUser,
      markWFHAttendance,
      wfhAuthorizedEmployees,
      authorizeEmployeeWFH,
      revokeEmployeeWFH,
      isEmployeeWFHAuthorized,
      getEmployeeWFHAuthInfo,

      // Digital ID Card Generation & HR Verification
      idCardRequests,
      requestIDCard,
      approveIDCardRequest,
      rejectIDCardRequest,
      getEmployeeIDCard,
      adminGenerateIDCard,

      leaves,
      leaveBalances,
      applyLeave,
      approveLeave,
      rejectLeave,

      payroll,
      markPayrollPaid,

      announcements,
      addAnnouncement,
      togglePinAnnouncement,
      deleteAnnouncement,
      markAnnouncementRead,

      jobOpenings,
      candidates,
      moveCandidateStage,
      addJobOpening,
      addCandidate,

      performanceReviews,
      addPerformanceReview,

      notifications,
      markNotificationRead,
      markAllNotificationsRead,
      deleteNotification,
      triggerNotification,

      // WiFi Geofence & Network Management
      companyWifis,
      currentNetwork,
      wifiEnforcementEnabled,
      availableNetworks: AVAILABLE_SIMULATION_NETWORKS,
      switchNetwork,
      addCompanyWifi,
      deleteCompanyWifi,
      toggleWifiEnforcement,
      toggleWifiAttendance,
      getWifiNetworkInfo,
      isCurrentWifiAuthorized,

      // Inventory Management Module
      inventoryProducts,
      inventorySuppliers,
      inventoryPurchaseOrders,
      inventoryStockMovements,
      addInventoryProduct,
      updateInventoryProduct,
      deleteInventoryProduct,
      performStockIn,
      performStockOut,
      addInventorySupplier,
      updateInventorySupplier,
      deleteInventorySupplier,
      createPurchaseOrder,
      updatePurchaseOrderStatus,

      auditLogs,
      logAudit
    }}>
      {children}
    </ERPContext.Provider>
  );
};

export const useERP = () => {
  const context = useContext(ERPContext);
  if (!context) throw new Error('useERP must be used within ERPProvider');
  return context;
};
